package br.com.aracaeru.jornadadasletras;

import android.app.Activity;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.view.WindowManager;
import android.view.View;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView game;
    private TextToSpeech tts;
    private boolean voiceReady = false;
    private String pendingSpeech = null;

    public class VoiceBridge {
        @JavascriptInterface
        public void speak(String phrase) {
            runOnUiThread(() -> {
                if (tts == null || !voiceReady) {
                    pendingSpeech = phrase;
                } else {
                    tts.stop();
                    tts.speak(phrase, TextToSpeech.QUEUE_FLUSH, null, "aracaeru-voice");
                }
            });
        }
        @JavascriptInterface
        public void stop() {
            runOnUiThread(() -> {
                pendingSpeech = null;
                if (tts != null) tts.stop();
            });
        }
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_FULLSCREEN);
        game = new WebView(this);
        game.setWebViewClient(new WebViewClient());
        game.setWebChromeClient(new WebChromeClient());
        WebSettings s = game.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        game.addJavascriptInterface(new VoiceBridge(), "AracaeruVoice");
        setContentView(game);
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS && tts != null) {
                tts.setLanguage(new Locale("pt", "BR"));
                tts.setSpeechRate(0.88f);
                tts.setPitch(1.12f);
                voiceReady = true;
                if (pendingSpeech != null) {
                    String phrase = pendingSpeech;
                    pendingSpeech = null;
                    tts.speak(phrase, TextToSpeech.QUEUE_FLUSH, null, "aracaeru-first");
                }
            }
        });
        game.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); tts = null; }
        if (game != null) { game.destroy(); game = null; }
        super.onDestroy();
    }
}
